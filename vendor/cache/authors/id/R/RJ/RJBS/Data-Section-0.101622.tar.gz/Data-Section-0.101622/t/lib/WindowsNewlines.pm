use strict;
use warnings;
package WindowsNewlines;
use Data::Section -setup;
1;
__DATA__
__[n]__
foo
