use strict;
use warnings;
package NoData;
use Data::Section -setup;

1;
