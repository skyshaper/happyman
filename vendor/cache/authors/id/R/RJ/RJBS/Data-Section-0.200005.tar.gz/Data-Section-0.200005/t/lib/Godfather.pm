use strict;
use warnings;
package Godfather;
1;
__DATA__
__[a]__
foo
