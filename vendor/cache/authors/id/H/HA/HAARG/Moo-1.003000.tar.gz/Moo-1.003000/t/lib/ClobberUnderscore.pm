package ClobberUnderscore;
sub h1 { 'h1' };
undef $_;
1;
