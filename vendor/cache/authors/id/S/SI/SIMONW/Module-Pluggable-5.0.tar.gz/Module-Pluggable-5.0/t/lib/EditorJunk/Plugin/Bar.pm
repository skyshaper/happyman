package EditorJunk::Bar;


use strict;


1;


