package SectionData;

use strict;
use warnings;

1;
__DATA__
__[ Section ]__
Hello.
__[ Section 2 ]__
More data.
