package Data;

use strict;
use warnings;

1;
__DATA__
Hello World.


This is a test file.
