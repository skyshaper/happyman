#
# just increment the value of $foo in the current package.
#
no strict;
$foo++;
